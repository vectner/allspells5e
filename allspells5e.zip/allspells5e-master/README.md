# allspells5e
myspells
install link
https://raw.githubusercontent.com/vectner/allspells5e/master/module.json
